package com.example.amanat.appathonq3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText editTextName, moneyOffered,editDte;
    Spinner spinnerGenre;
    Button buttonAddArtist;
    ListView listViewArtists;

    //a list to store all the artist from firebase database
    List<Artist> artists;

    //our database reference object
    DatabaseReference databaseArtists;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databaseArtists = FirebaseDatabase.getInstance().getReference("artists");
        //getting views
        editTextName = (EditText) findViewById(R.id.editTextName);
        moneyOffered = (EditText) findViewById(R.id.moneyOffered);
        editDte = (EditText) findViewById(R.id.date);
        spinnerGenre = (Spinner) findViewById(R.id.spinnerGenres);
        listViewArtists = (ListView) findViewById(R.id.listViewArtists);
        buttonAddArtist = (Button) findViewById(R.id.buttonAddArtist);
        //list to store artists
        artists = new ArrayList<>();
        buttonAddArtist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                addArtist();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        //attaching value event listener
        databaseArtists.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //clearing the previous artist list
                artists.clear();
                //iterating through all the nodes
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    //getting artist
                    Artist artist = postSnapshot.getValue(Artist.class);
                    artists.add(artist);
                }
                //creating adapter
                ArtistList artistAdapter = new ArtistList(MainActivity.this, artists);
                listViewArtists.setAdapter(artistAdapter);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
    private void addArtist() {
        String name = editTextName.getText().toString().trim();
        String genre = spinnerGenre.getSelectedItem().toString();
        String money = moneyOffered.getText().toString().trim();
        String date = editDte.getText().toString().trim();
        //checking if the value is provided
        if ((!TextUtils.isEmpty(name)) && (!TextUtils.isEmpty(genre)) && (!TextUtils.isEmpty(money))&&(!TextUtils.isEmpty(date))){
            String id = databaseArtists.push().getKey();
            Artist artist = new Artist(id, name, genre,money,date);
            databaseArtists.child(id).setValue(artist);
            editTextName.setText("");
            moneyOffered.setText("");
            editDte.setText("");
            Toast.makeText(this, "New entry added", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Please enter valid details", Toast.LENGTH_LONG).show();
        }
    }
}

