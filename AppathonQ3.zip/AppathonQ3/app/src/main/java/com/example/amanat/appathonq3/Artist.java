package com.example.amanat.appathonq3;
import android.support.v7.app.AppCompatActivity;
public class Artist extends AppCompatActivity{
    String artistId;
    String artistName;
    String artistGenres;
    String moneyOffered;
    String date;

    public Artist(){};

    public Artist(String artistId, String artistName, String artistGenres, String moneyOffered, String date) {
        this.artistId = artistId;
        this.artistName = artistName;
        this.artistGenres = artistGenres;
        this.moneyOffered = moneyOffered;
        this.date = date;
    }

    public String getArtistId() {
        return artistId;
    }

    public String getArtistName() {
        return artistName;
    }

    public String getArtistGenres() {
        return artistGenres;
    }

    public String getMoneyOffered() {
        return moneyOffered;
    }

    public String getDate() {
        return date;
    }
    public String determineRange(int moneyOffered) {
        String severity;
        int c = moneyOffered;
        if (0 <= c && c > 5000) {
            severity = "Clean slate";
        }
        if (5000 <= c && c > 20000) {
            severity = "Moderate Corruption";
        }
        if (20000 <= c && c < 50000) {
            severity = "Highly Corruption";
        } else {
            severity = "Severly Corrupt";
        }
        return severity;
    }
}