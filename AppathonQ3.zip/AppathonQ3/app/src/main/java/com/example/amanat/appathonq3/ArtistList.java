package com.example.amanat.appathonq3;
import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ArtistList extends ArrayAdapter<Artist> {

    private Activity context;
    List<Artist> artists;
    public ArtistList(Activity context, List<Artist> artists) {
        super(context, R.layout.list_layout, artists);
        this.context = context;
        this.artists = artists;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.list_layout, null, true);

        TextView textViewName = (TextView) listViewItem.findViewById(R.id.textViewName);
        TextView textViewGenre = (TextView) listViewItem.findViewById(R.id.textViewGenre);
        TextView textViewMoneyOffered = (TextView) listViewItem.findViewById(R.id.textViewMoneyOffered);
        TextView textViewDate = (TextView) listViewItem.findViewById(R.id.textViewDate);
        TextView textViewSeverity = (TextView) listViewItem.findViewById(R.id.textViewSeverity);
        Artist artist = artists.get(position);
        textViewName.setText(artist.getArtistName());
        textViewGenre.setText(artist.getArtistGenres());
        textViewMoneyOffered.setText(artist.getMoneyOffered());
        textViewDate.setText(artist.getDate());
        textViewSeverity.setText(artist.determineRange(Integer.parseInt(artist.getMoneyOffered())));
        return listViewItem;
    }
}

